#ifndef USERPROG_TEST_MAIN_H
#define USERPROG_TEST_MAIN_H

void palloc_test_main(void);

#endif /* tests/main.h */
 